"""
Configuration management utility
"""

import os
from dotenv import load_dotenv
import json


class Config:
    """Configuration class for managing test settings"""
    
    # Load environment variables
    load_dotenv()
    
    # Environment settings
    BASE_URL = os.getenv("BASE_URL", "https://insurance-portal.example.com")
    API_URL = os.getenv("API_URL", "https://api.insurance-portal.example.com")
    
    # Browser settings
    HEADLESS = os.getenv("HEADLESS", "true").lower() == "true"
    BROWSER = os.getenv("BROWSER", "chromium")
    BROWSER_TIMEOUT = int(os.getenv("BROWSER_TIMEOUT", "30000"))
    BROWSER_VIEWPORT = {"width": 1920, "height": 1080}
    
    # Authentication settings
    TEST_USERNAME = os.getenv("USERNAME", "testuser")
    TEST_PASSWORD = os.getenv("PASSWORD", "testpass")
    TEST_EMAIL = f"{TEST_USERNAME}@example.com"
    TEST_FULL_NAME = "Test User"
    TEST_ROLE = "customer"
    
    # Admin settings
    ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
    ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "adminpass")
    ADMIN_EMAIL = f"{ADMIN_USERNAME}@example.com"
    ADMIN_FULL_NAME = "Admin User"
    
    # Agent settings
    AGENT_USERNAME = os.getenv("AGENT_USERNAME", "agent")
    AGENT_PASSWORD = os.getenv("AGENT_PASSWORD", "agentpass")
    AGENT_EMAIL = f"{AGENT_USERNAME}@example.com"
    AGENT_FULL_NAME = "Agent User"
    
    # Database settings
    DB_HOST = os.getenv("DB_HOST", "localhost")
    DB_PORT = int(os.getenv("DB_PORT", "5432"))
    DB_NAME = os.getenv("DB_NAME", "insurance_test")
    DB_USER = os.getenv("DB_USER", "test_user")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "test_password")
    
    # Allure settings
    ALLURE_RESULTS_DIR = os.getenv("ALLURE_RESULTS_DIR", "reports/allure")
    ALLURE_REPORT_DIR = os.getenv("ALLURE_REPORT_DIR", "reports/allure-report")
    
    # Logging settings
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE = os.getenv("LOG_FILE", "logs/execution.log")
    
    # Test data paths
    USERS_FILE = os.getenv("USERS_FILE", "data/users.xlsx")
    TESTDATA_FILE = os.getenv("TESTDATA_FILE", "data/testdata.xlsx")
    ENV_FILE = os.getenv("ENV_FILE", "data/env.json")
    ROLES_FILE = os.getenv("ROLES_FILE", "data/roles.json")
    
    # Timeouts
    PAGE_LOAD_TIMEOUT = 30000
    ELEMENT_WAIT_TIMEOUT = 10000
    AJAX_WAIT_TIMEOUT = 5000
    
    @classmethod
    def get_environment_config(cls, env_file: str = None) -> dict:
        """Load environment configuration from JSON file"""
        if env_file is None:
            env_file = cls.ENV_FILE
        
        try:
            with open(env_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return {"environments": {}, "default_environment": "dev"}
    
    @classmethod
    def get_current_environment(cls) -> str:
        """Get current environment name"""
        env_config = cls.get_environment_config()
        return env_config.get("default_environment", "dev")
    
    @classmethod
    def get_base_url(cls, environment: str = None) -> str:
        """Get base URL for specific environment"""
        if environment is None:
            environment = cls.get_current_environment()
        
        env_config = cls.get_environment_config()
        environments = env_config.get("environments", {})
        
        if environment in environments:
            return environments[environment].get("base_url", cls.BASE_URL)
        
        return cls.BASE_URL
