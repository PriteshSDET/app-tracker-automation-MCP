import pytest
from playwright.sync_api import Page, BrowserContext, Browser
from utils.config import Config
from utils.logger import Logger

@pytest.fixture(scope="session")
def browser(browser_type):
    """Browser fixture for Playwright"""
    browser = browser_type.launch(headless=Config.HEADLESS)
    yield browser
    browser.close()

@pytest.fixture(scope="function")
def page(browser: Browser):
    """Page fixture for Playwright"""
    context = browser.new_context()
    page = context.new_page()
    yield page
    page.close()
    context.close()

@pytest.fixture(scope="session")
def config():
    """Configuration fixture"""
    return Config()

@pytest.fixture(scope="function")
def logger():
    """Logger fixture"""
    return Logger()
